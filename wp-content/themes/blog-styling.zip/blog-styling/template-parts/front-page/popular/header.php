<?php
/**
 * Header del bloque de últimas noticias
 *
 * @package WordPress
 * @subpackage Monmedios
 */

?>

<div class="-row">
    <div class="-col-12">
        <div class="m-lastArticle__header">
            <h2 class="m-lastArticle__title">Popular</h2><!-- .m-lastArticle__title -->
        </div><!-- .m-lastArticle__header -->
    </div>
</div>