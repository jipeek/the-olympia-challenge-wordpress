<?php
/**
 * Site Footer
 *
 * @package WordPress
 * @subpackage Monmedios
 */
?>

<div class="m-footer__firm">
    <p class="a-footer__copyright"><?php echo '© '. date('Y') . ' Jipeek'; ?></p>
    <p class="a-footer__dev">Hecho con <a href="https://hacktzi.com" class="-monlogo" target="_blank">❤</a></p>
</div>